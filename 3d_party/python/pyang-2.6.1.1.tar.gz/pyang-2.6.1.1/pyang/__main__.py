#!/usr/bin/env python
import sys
import re
from pyang.scripts.pyang_tool import run


sys.exit(run())