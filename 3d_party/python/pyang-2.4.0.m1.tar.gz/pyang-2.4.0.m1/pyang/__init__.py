"""The pyang library for parsing, validating, and converting YANG modules"""

__version__ = '2.4.0.m1'
__date__ = '2021-02-01'
